import classes from './NewPost.module.css';
// import { useState } from 'react';



function NewPost({onBodyChange, onAuthorChange, onCancel}) {

    // const [enteredBody, setEnteredBody] = useState('');
    
    return (
        <form className={classes.form} onSubmit={}>
            <p>
                <label htmlFor="body">Text</label>
                <textarea id="body" required rows={3} onChange={onBodyChange}
                />
            </p>
            {/* <p>
                {enteredBody}
            </p> */}
            <p>
                <label htmlFor="name">Your name</label>
                <input type="text" id="name" required onChange={onAuthorChange} />
            </p>
            <p className={classes.actions}>
                <button type='button' onClick={onCancel}>Cancel</button>
                {/* the above line will not submit the form, else the default of action of any... */}
                {/* button in html is to submit the form */}
                <button>Submit</button>
            </p>
        </form>
    );
}

export default NewPost;